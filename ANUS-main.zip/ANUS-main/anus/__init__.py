"""
Anus - Autonomous Networked Utility System
Package initialization
"""

__version__ = "0.1.0"
__author__ = "Anus AI Team"
__email__ = "anus-ai@example.com"
__description__ = "An open-source AI agent framework for task automation"
