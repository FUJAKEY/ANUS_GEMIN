<!-- Badges for the Anus AI project -->

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![Contributions welcome](https://img.shields.io/badge/contributions-welcome-brightgreen.svg)](https://github.com/anus-ai/anus/blob/main/CONTRIBUTING.md)
[![GitHub stars](https://img.shields.io/github/stars/anus-ai/anus.svg?style=social&label=Star)](https://github.com/anus-ai/anus)
[![GitHub forks](https://img.shields.io/github/forks/anus-ai/anus.svg?style=social&label=Fork)](https://github.com/anus-ai/anus)
[![GitHub issues](https://img.shields.io/github/issues/anus-ai/anus.svg)](https://github.com/anus-ai/anus/issues)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](https://makeapullrequest.com)
[![Documentation Status](https://img.shields.io/badge/docs-latest-brightgreen.svg)](https://anus-ai.github.io/docs)
[![Telegram](https://img.shields.io/badge/Telegram-blue?logo=telegram&logoColor=white)](https://t.me/goanus)
